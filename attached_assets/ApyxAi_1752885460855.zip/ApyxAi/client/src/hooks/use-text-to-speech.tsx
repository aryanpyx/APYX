import { useState, useCallback, useRef, useEffect } from 'react';
import { VoiceSettings } from '@shared/types';

export type VoiceGender = 'male' | 'female';

interface UseTextToSpeechReturn {
  speak: (text: string, settings?: Partial<VoiceSettings>) => void;
  stop: () => void;
  isSpeaking: boolean;
  isSupported: boolean;
  availableVoices: SpeechSynthesisVoice[];
  setVoiceGender: (gender: VoiceGender) => void;
  voiceGender: VoiceGender;
}

export function useTextToSpeech(): UseTextToSpeechReturn {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceGender, setVoiceGender] = useState<VoiceGender>('male');
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const isSupported = 'speechSynthesis' in window;

  // Load available voices
  useEffect(() => {
    if (!isSupported) return;

    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      setAvailableVoices(voices);
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, [isSupported]);

  // Enhanced voice selection logic
  const selectVoice = useCallback((language: string, gender: VoiceGender): SpeechSynthesisVoice | null => {
    if (availableVoices.length === 0) return null;

    // Language mapping
    const langMap: { [key: string]: string[] } = {
      'en': ['en-GB', 'en-US', 'en-AU'],
      'hi': ['hi-IN', 'hi'],
      'bho': ['hi-IN', 'hi', 'en-IN'] // Fallback for Bhojpuri
    };

    const targetLangs = langMap[language] || ['en-US'];
    
    // Filter voices by language and gender
    const filteredVoices = availableVoices.filter(voice => {
      const matchesLang = targetLangs.some(lang => voice.lang.startsWith(lang));
      const voiceName = voice.name.toLowerCase();
      
      // Gender detection heuristics
      const isMale = voiceName.includes('male') || 
                    voiceName.includes('david') || 
                    voiceName.includes('daniel') || 
                    voiceName.includes('alex') ||
                    voiceName.includes('thomas') ||
                    voiceName.includes('arthur');
      
      const isFemale = voiceName.includes('female') || 
                      voiceName.includes('samantha') || 
                      voiceName.includes('victoria') || 
                      voiceName.includes('karen') ||
                      voiceName.includes('susan') ||
                      voiceName.includes('fiona');

      if (gender === 'male' && isFemale) return false;
      if (gender === 'female' && isMale) return false;
      
      return matchesLang;
    });

    // Prefer British voices for English
    if (language === 'en') {
      const britishVoice = filteredVoices.find(voice => 
        voice.lang.startsWith('en-GB') || 
        voice.name.toLowerCase().includes('british') ||
        voice.name.toLowerCase().includes('uk')
      );
      if (britishVoice) return britishVoice;
    }

    // Return the first matching voice or fallback
    return filteredVoices[0] || availableVoices[0] || null;
  }, [availableVoices]);

  const speak = useCallback((text: string, settings: Partial<VoiceSettings> = {}) => {
    if (!isSupported) {
      console.warn('Speech synthesis not supported');
      return;
    }

    // Stop any current speech immediately to prevent overlap
    if (synthRef.current) {
      synthRef.current.cancel();
    }

    // Wait a moment to ensure cancellation is complete
    setTimeout(() => {
      synthRef.current = window.speechSynthesis;
      utteranceRef.current = new SpeechSynthesisUtterance(text);

      // Configure voice settings
      utteranceRef.current.rate = settings.speed || 1;
      utteranceRef.current.pitch = settings.pitch || 1;

      // Auto-detect language from text or use default
      const detectedLang = settings.language || 'en';
      const selectedVoice = selectVoice(detectedLang, voiceGender);
      
      if (selectedVoice) {
        utteranceRef.current.voice = selectedVoice;
        utteranceRef.current.lang = selectedVoice.lang;
      }

      utteranceRef.current.onstart = () => {
        setIsSpeaking(true);
      };

      utteranceRef.current.onend = () => {
        setIsSpeaking(false);
      };

      utteranceRef.current.onerror = (event) => {
        console.error('Speech synthesis error:', event.error);
        setIsSpeaking(false);
      };

      synthRef.current.speak(utteranceRef.current);
    }, 100);
  }, [isSupported, voiceGender, selectVoice]);

  const stop = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const updateVoiceGender = useCallback((gender: VoiceGender) => {
    // Stop current speech when changing gender
    if (isSpeaking) {
      stop();
    }
    setVoiceGender(gender);
  }, [isSpeaking, stop]);

  return {
    speak,
    stop,
    isSpeaking,
    isSupported,
    availableVoices,
    setVoiceGender: updateVoiceGender,
    voiceGender,
  };
}
