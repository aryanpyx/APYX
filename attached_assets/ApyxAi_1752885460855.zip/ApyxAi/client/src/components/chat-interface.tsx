import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Send, MessageCircle, Bot, User } from 'lucide-react';
import { Message } from '@shared/types';
import { sendChatMessage } from '@/lib/openai-client';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';

interface ChatInterfaceProps {
  messages: Message[];
  onNewMessage: (message: Message) => void;
  onNewResponse: (message: Message) => void;
  selectedLanguage: string;
}

export function ChatInterface({ messages, onNewMessage, onNewResponse, selectedLanguage }: ChatInterfaceProps) {
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { speak } = useTextToSpeech();

  const getGreeting = (language: string) => {
    switch (language) {
      case 'hi':
        return 'नमस्ते आर्यन जी! मैं APYX हूं, आपका AI सहायक। आज मैं आपकी कैसे सहायता कर सकता हूं?';
      case 'bho':
        return 'नमस्कार आर्यन जी! हम APYX बानी, रउआ के AI सहायक। आज हम रउआ के कइसे मदद कर सकीं?';
      default:
        return 'Good morning! I\'m APYX, your AI assistant. How may I help you today?';
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    onNewMessage(userMessage);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await sendChatMessage({ 
        message: inputMessage,
        language: selectedLanguage 
      });
      
      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        content: response.message,
        sender: 'assistant',
        timestamp: new Date(response.timestamp),
      };

      onNewResponse(assistantMessage);
      
      // Speak the response with British accent
      speak(response.message, { britishAccent: true });
    } catch (error) {
      console.error('Failed to send message:', error);
      
      const errorMessage: Message = {
        id: crypto.randomUUID(),
        content: 'I apologize, but I encountered an error processing your request. Please try again.',
        sender: 'assistant',
        timestamp: new Date(),
      };
      
      onNewResponse(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className="mb-8 bg-jarvis-surface/30 backdrop-blur-md border-jarvis-blue/20">
      <CardHeader className="border-b border-jarvis-blue/20">
        <CardTitle className="jarvis-accent flex items-center">
          <MessageCircle className="mr-2 h-5 w-5" />
          Conversation
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="h-96 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-jarvis-blue to-jarvis-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div className="bg-jarvis-surface/50 rounded-lg p-3 max-w-xs">
                <p className="text-sm jarvis-glow">
                  {getGreeting(selectedLanguage)}
                </p>
                <span className="text-xs text-slate-400 mt-1 block">Just now</span>
              </div>
            </div>
          )}
          
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.sender === 'user' ? 'justify-end' : ''
              }`}
            >
              {message.sender === 'user' ? (
                <>
                  <div className="bg-jarvis-blue/80 rounded-lg p-3 max-w-xs">
                    <p className="text-sm text-white">{message.content}</p>
                    <span className="text-xs text-blue-200 mt-1 block">
                      {formatTime(message.timestamp)}
                    </span>
                  </div>
                  <div className="w-8 h-8 bg-jarvis-blue rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4 text-white" />
                  </div>
                </>
              ) : (
                <>
                  <div className="w-8 h-8 bg-gradient-to-r from-jarvis-blue to-jarvis-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                  <div className="bg-jarvis-surface/50 rounded-lg p-3 max-w-xs">
                    <p className="text-sm jarvis-glow">{message.content}</p>
                    <span className="text-xs text-slate-400 mt-1 block">
                      {formatTime(message.timestamp)}
                    </span>
                  </div>
                </>
              )}
            </div>
          ))}
          
          {isLoading && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-jarvis-blue to-jarvis-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div className="bg-jarvis-surface/50 rounded-lg p-3 max-w-xs">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-jarvis-accent rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-jarvis-accent rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-jarvis-accent rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-4 border-t border-jarvis-blue/20">
          <div className="flex space-x-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={isLoading}
              className="flex-1 bg-jarvis-surface/50 border-jarvis-blue/20 jarvis-glow placeholder-slate-400 focus:border-jarvis-blue/50"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isLoading}
              className="bg-jarvis-blue hover:bg-jarvis-accent"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
