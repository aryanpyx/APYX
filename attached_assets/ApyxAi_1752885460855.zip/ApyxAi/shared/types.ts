export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

export interface VoiceSettings {
  speed: number;
  pitch: number;
  britishAccent: boolean;
  language?: string;
}

export interface ChatRequest {
  message: string;
  language?: string;
}

export interface ChatResponse {
  message: string;
  timestamp: Date;
}

export interface QuickAction {
  id: string;
  name: string;
  icon: string;
  command: string;
}
