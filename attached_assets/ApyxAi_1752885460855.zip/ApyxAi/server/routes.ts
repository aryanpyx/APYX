import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { getChatResponse, getQuickActionResponse } from "./services/openai";
import { storage } from "./storage";
import { insertConversationSchema, insertMessageSchema } from "@shared/schema";

const chatRequestSchema = z.object({
  message: z.string().min(1),
  language: z.string().optional(),
});

const quickResponseSchema = z.object({
  command: z.string().min(1),
  language: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint for general conversation
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language } = chatRequestSchema.parse(req.body);
      
      const response = await getChatResponse(message, language);
      
      res.json({
        message: response,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Chat endpoint error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request format" 
        });
      }
      
      res.status(500).json({ 
        message: "I apologize, but I'm experiencing technical difficulties. Please try again in a moment." 
      });
    }
  });

  // Quick response endpoint for preset commands
  app.post("/api/quick-response", async (req, res) => {
    try {
      const { command } = quickResponseSchema.parse(req.body);
      
      const response = await getQuickActionResponse(command, req.body.language);
      
      res.json({
        message: response,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Quick response endpoint error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid command format" 
        });
      }
      
      res.status(500).json({ 
        message: "I apologize, but I'm having difficulty processing that command at the moment." 
      });
    }
  });

  // Conversation endpoints
  app.post("/api/conversations", async (req, res) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(conversationData);
      res.status(201).json(conversation);
    } catch (error) {
      console.error('Create conversation error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid conversation data" });
      }
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      res.json(conversation);
    } catch (error) {
      console.error('Get conversation error:', error);
      res.status(500).json({ message: "Failed to retrieve conversation" });
    }
  });

  app.get("/api/users/:userId/conversations", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const conversations = await storage.getUserConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error('Get user conversations error:', error);
      res.status(500).json({ message: "Failed to retrieve conversations" });
    }
  });

  // Message endpoints
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      console.error('Create message error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data" });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  app.get("/api/conversations/:conversationId/messages", async (req, res) => {
    try {
      const messages = await storage.getConversationMessages(req.params.conversationId);
      res.json(messages);
    } catch (error) {
      console.error('Get conversation messages error:', error);
      res.status(500).json({ message: "Failed to retrieve messages" });
    }
  });

  // Enhanced chat endpoint with conversation persistence
  app.post("/api/chat/persist", async (req, res) => {
    try {
      const { message, language, conversationId, userId, isVoiceInput } = req.body;
      
      if (!message || !conversationId) {
        return res.status(400).json({ message: "Message and conversation ID are required" });
      }

      // Save user message
      await storage.createMessage({
        conversationId,
        content: message,
        sender: 'user',
        language: language || 'en',
        isVoiceInput: isVoiceInput || false
      });

      // Get AI response
      const response = await getChatResponse(message, language);
      
      // Save AI response
      const aiMessage = await storage.createMessage({
        conversationId,
        content: response,
        sender: 'assistant',
        language: language || 'en',
        isVoiceInput: false
      });
      
      res.json({
        message: response,
        messageId: aiMessage.id,
        timestamp: aiMessage.timestamp,
      });
    } catch (error) {
      console.error('Persistent chat error:', error);
      res.status(500).json({ 
        message: "I apologize, but I'm experiencing technical difficulties. Please try again in a moment." 
      });
    }
  });

  // User preferences endpoint
  app.patch("/api/users/:userId/preferences", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const { language, voiceSettings } = req.body;
      const user = await storage.updateUserPreferences(userId, language, voiceSettings);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error('Update user preferences error:', error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "APYX is online and ready to assist",
      timestamp: new Date().toISOString(),
      database: "Connected"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
