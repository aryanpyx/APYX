import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { X, Settings, Volume2, Palette, Key } from 'lucide-react';
import { VoiceSettings } from '@shared/types';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: VoiceSettings;
  onVoiceSettingsChange: (settings: VoiceSettings) => void;
}

export function SettingsPanel({ 
  isOpen, 
  onClose, 
  voiceSettings, 
  onVoiceSettingsChange 
}: SettingsPanelProps) {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const updateVoiceSetting = (key: keyof VoiceSettings, value: any) => {
    onVoiceSettingsChange({
      ...voiceSettings,
      [key]: value,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 transition-all duration-300">
      <div className="absolute right-0 top-0 h-full w-80 bg-jarvis-surface border-l border-jarvis-blue/20 transform transition-transform duration-300">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold jarvis-accent">Settings</h2>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="rounded-full hover:bg-jarvis-blue/20"
            >
              <X className="h-4 w-4 jarvis-accent" />
            </Button>
          </div>
          
          {/* Voice Settings */}
          <Card className="mb-6 bg-jarvis-surface/50 border-jarvis-blue/20">
            <CardHeader>
              <CardTitle className="jarvis-glow flex items-center text-lg">
                <Volume2 className="mr-2 h-4 w-4" />
                Voice Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-2">
                  Voice Speed: {voiceSettings.speed.toFixed(1)}x
                </label>
                <Slider
                  value={[voiceSettings.speed]}
                  onValueChange={([value]) => updateVoiceSetting('speed', value)}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm text-slate-300 mb-2">
                  Voice Pitch: {voiceSettings.pitch.toFixed(1)}
                </label>
                <Slider
                  value={[voiceSettings.pitch]}
                  onValueChange={([value]) => updateVoiceSetting('pitch', value)}
                  min={0}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-300">British Accent</span>
                <Switch
                  checked={voiceSettings.britishAccent}
                  onCheckedChange={(checked) => updateVoiceSetting('britishAccent', checked)}
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Theme Settings */}
          <Card className="mb-6 bg-jarvis-surface/50 border-jarvis-blue/20">
            <CardHeader>
              <CardTitle className="jarvis-glow flex items-center text-lg">
                <Palette className="mr-2 h-4 w-4" />
                Theme
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-300">Dark Mode</span>
                <Switch
                  checked={isDarkMode}
                  onCheckedChange={setIsDarkMode}
                />
              </div>
            </CardContent>
          </Card>
          
          {/* API Settings */}
          <Card className="bg-jarvis-surface/50 border-jarvis-blue/20">
            <CardHeader>
              <CardTitle className="jarvis-glow flex items-center text-lg">
                <Key className="mr-2 h-4 w-4" />
                API Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline"
                className="w-full bg-jarvis-blue/20 border-jarvis-blue/40 jarvis-accent hover:bg-jarvis-blue/30"
              >
                Configure OpenAI API
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
