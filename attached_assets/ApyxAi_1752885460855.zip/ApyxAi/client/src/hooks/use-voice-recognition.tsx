import { useState, useCallback, useRef, useEffect } from 'react';

interface VoiceRecognitionResult {
  transcript: string;
  confidence: number;
  isFinal: boolean;
  detectedLanguage?: string;
}

interface UseVoiceRecognitionReturn {
  isListening: boolean;
  isSupported: boolean;
  transcript: string;
  language: string;
  detectedLanguage: string;
  isWakeWordListening: boolean;
  startListening: (lang?: string) => void;
  stopListening: () => void;
  resetTranscript: () => void;
  setLanguage: (lang: string) => void;
  startWakeWordDetection: () => void;
  stopWakeWordDetection: () => void;
}

export function useVoiceRecognition(): UseVoiceRecognitionReturn {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [language, setLanguage] = useState('en-US');
  const [detectedLanguage, setDetectedLanguage] = useState('en');
  const [isWakeWordListening, setIsWakeWordListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const wakeWordRecognitionRef = useRef<SpeechRecognition | null>(null);

  const isSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;

  const getLanguageCode = (lang: string) => {
    switch (lang) {
      case 'hi': return 'hi-IN';
      case 'bho': return 'hi-IN'; // Bhojpuri uses Hindi recognition as fallback
      case 'en': return 'en-US';
      default: return 'en-US';
    }
  };

  // Automatic language detection based on text content
  const detectLanguage = (text: string): string => {
    const lowerText = text.toLowerCase();
    
    // Hindi/Devanagari script detection
    if (/[\u0900-\u097F]/.test(text)) {
      return 'hi';
    }
    
    // Common Hindi words in Latin script
    const hindiWords = ['namaste', 'kaise', 'aap', 'main', 'hoon', 'kya', 'hai', 'nahin', 'haan', 'accha'];
    if (hindiWords.some(word => lowerText.includes(word))) {
      return 'hi';
    }
    
    // Common Bhojpuri words
    const bhojpuriWords = ['kaise', 'ban', 'raha', 'batao', 'kaha', 'jaa', 'bhaiya', 'didi'];
    if (bhojpuriWords.some(word => lowerText.includes(word))) {
      return 'bho';
    }
    
    // Default to English
    return 'en';
  };

  // Wake word detection patterns
  const wakeWords = {
    en: ['hey dude', 'hey apyx', 'hello apyx', 'wake up apyx'],
    hi: ['hey dude', 'hey apyx', 'सुनो अपिक्स', 'हेलो अपिक्स', 'अरे दोस्त'],
    bho: ['अरे यार', 'सुनो भाई', 'hey dude', 'अपिक्स सुनो']
  };

  const detectWakeWord = (text: string): boolean => {
    const lowerText = text.toLowerCase();
    const allWakeWords = Object.values(wakeWords).flat();
    return allWakeWords.some(word => lowerText.includes(word.toLowerCase()));
  };

  const startListening = useCallback((lang?: string) => {
    if (!isSupported) {
      console.warn('Speech recognition not supported');
      return;
    }

    const targetLang = lang ? getLanguageCode(lang) : language;
    setLanguage(targetLang);

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();

    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;
    recognitionRef.current.lang = targetLang;

    recognitionRef.current.onstart = () => {
      setIsListening(true);
    };

    recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcriptPart = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcriptPart;
        } else {
          interimTranscript += transcriptPart;
        }
      }

      const fullTranscript = finalTranscript || interimTranscript;
      setTranscript(fullTranscript);
      
      // Auto-detect language from the transcript
      if (fullTranscript.trim()) {
        const detected = detectLanguage(fullTranscript);
        setDetectedLanguage(detected);
      }
    };

    recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognitionRef.current.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current.start();
  }, [isSupported, language]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  }, []);

  const resetTranscript = useCallback(() => {
    setTranscript('');
  }, []);

  // Wake word detection functionality
  const startWakeWordDetection = useCallback(() => {
    if (!isSupported || isWakeWordListening) return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    wakeWordRecognitionRef.current = new SpeechRecognition();

    wakeWordRecognitionRef.current.continuous = true;
    wakeWordRecognitionRef.current.interimResults = true;
    wakeWordRecognitionRef.current.lang = 'en-US'; // Use English for wake word detection

    wakeWordRecognitionRef.current.onstart = () => {
      setIsWakeWordListening(true);
    };

    wakeWordRecognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }

      if (detectWakeWord(transcript)) {
        // Wake word detected, start main listening
        stopWakeWordDetection();
        startListening();
      }
    };

    wakeWordRecognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Wake word recognition error:', event.error);
      setIsWakeWordListening(false);
    };

    wakeWordRecognitionRef.current.onend = () => {
      setIsWakeWordListening(false);
      // Restart wake word detection if it wasn't manually stopped
      setTimeout(() => {
        if (!isListening && isSupported) {
          startWakeWordDetection();
        }
      }, 1000);
    };

    wakeWordRecognitionRef.current.start();
  }, [isSupported, isWakeWordListening, isListening]);

  const stopWakeWordDetection = useCallback(() => {
    if (wakeWordRecognitionRef.current) {
      wakeWordRecognitionRef.current.stop();
      setIsWakeWordListening(false);
    }
  }, []);

  const updateLanguage = useCallback((lang: string) => {
    setLanguage(getLanguageCode(lang));
  }, []);

  // Auto-start wake word detection on mount
  useEffect(() => {
    if (isSupported && !isListening) {
      startWakeWordDetection();
    }
    
    return () => {
      stopWakeWordDetection();
    };
  }, []);

  return {
    isListening,
    isSupported,
    transcript,
    language,
    detectedLanguage,
    isWakeWordListening,
    startListening,
    stopListening,
    resetTranscript,
    setLanguage: updateLanguage,
    startWakeWordDetection,
    stopWakeWordDetection,
  };
}
