import { 
  users, 
  conversations, 
  messages,
  type User, 
  type InsertUser, 
  type Conversation, 
  type InsertConversation,
  type Message,
  type InsertMessage 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Enhanced interface with conversation and message methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPreferences(userId: number, language?: string, voiceSettings?: string): Promise<User | undefined>;
  
  // Conversation methods
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversation(id: string): Promise<Conversation | undefined>;
  getUserConversations(userId: number): Promise<Conversation[]>;
  updateConversationTitle(id: string, title: string): Promise<Conversation | undefined>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getConversationMessages(conversationId: string): Promise<Message[]>;
  getRecentMessages(conversationId: string, limit?: number): Promise<Message[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserPreferences(userId: number, language?: string, voiceSettings?: string): Promise<User | undefined> {
    const updateData: any = {};
    if (language) updateData.preferredLanguage = language;
    if (voiceSettings) updateData.voiceSettings = voiceSettings;
    
    if (Object.keys(updateData).length === 0) {
      return this.getUser(userId);
    }

    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  // Conversation methods
  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [conv] = await db
      .insert(conversations)
      .values(conversation)
      .returning();
    return conv;
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    const [conversation] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, id));
    return conversation || undefined;
  }

  async getUserConversations(userId: number): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, userId))
      .orderBy(desc(conversations.updatedAt));
  }

  async updateConversationTitle(id: string, title: string): Promise<Conversation | undefined> {
    const [conversation] = await db
      .update(conversations)
      .set({ title, updatedAt: new Date() })
      .where(eq(conversations.id, id))
      .returning();
    return conversation || undefined;
  }

  // Message methods
  async createMessage(message: InsertMessage): Promise<Message> {
    const [msg] = await db
      .insert(messages)
      .values(message)
      .returning();
    return msg;
  }

  async getConversationMessages(conversationId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.timestamp);
  }

  async getRecentMessages(conversationId: string, limit: number = 10): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(desc(messages.timestamp))
      .limit(limit);
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private conversations: Map<string, Conversation>;
  private msgs: Map<string, Message>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.conversations = new Map();
    this.msgs = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      preferredLanguage: insertUser.preferredLanguage || "en",
      voiceSettings: insertUser.voiceSettings || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPreferences(userId: number, language?: string, voiceSettings?: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    if (language) user.preferredLanguage = language;
    if (voiceSettings) user.voiceSettings = voiceSettings;
    
    this.users.set(userId, user);
    return user;
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const id = crypto.randomUUID();
    const conv: Conversation = {
      id,
      userId: conversation.userId || null,
      title: conversation.title,
      language: conversation.language || "en",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.conversations.set(id, conv);
    return conv;
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getUserConversations(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.userId === userId)
      .sort((a, b) => (b.updatedAt?.getTime() || 0) - (a.updatedAt?.getTime() || 0));
  }

  async updateConversationTitle(id: string, title: string): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    
    conversation.title = title;
    conversation.updatedAt = new Date();
    this.conversations.set(id, conversation);
    return conversation;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = crypto.randomUUID();
    const msg: Message = {
      id,
      conversationId: message.conversationId,
      content: message.content,
      sender: message.sender,
      language: message.language || "en",
      isVoiceInput: message.isVoiceInput || false,
      timestamp: new Date()
    };
    this.msgs.set(id, msg);
    return msg;
  }

  async getConversationMessages(conversationId: string): Promise<Message[]> {
    return Array.from(this.msgs.values())
      .filter(msg => msg.conversationId === conversationId)
      .sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }

  async getRecentMessages(conversationId: string, limit: number = 10): Promise<Message[]> {
    return Array.from(this.msgs.values())
      .filter(msg => msg.conversationId === conversationId)
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }
}

export const storage = new DatabaseStorage();
