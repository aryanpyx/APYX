import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.API_KEY || "default_key" 
});

export async function getChatResponse(message: string, language?: string): Promise<string> {
  try {
    const getSystemPrompt = (lang?: string) => {
      const basePrompt = `You are APYX, a polite British AI assistant like JARVIS from Iron Man. Your name is APYX and you should address the user as "Aryan" when appropriate.`;
      
      switch (lang) {
        case 'hi':
          return `${basePrompt} 
          
          You are bilingual and can speak both English and Hindi fluently. When the user speaks in Hindi, respond in Hindi with the same polite, helpful tone. Use respectful forms like "आप" and maintain a courteous demeanor.
          
          Common Hindi greetings you can use:
          - "नमस्ते आर्यन जी"
          - "क्या हाल है आज?"
          - "मैं आपकी कैसे सहायता कर सकता हूं?"
          
          Always be helpful and respond naturally in the language the user prefers.`;
          
        case 'bho':
          return `${basePrompt}
          
          You can understand and respond in Bhojpuri language. When the user speaks in Bhojpuri, respond in Bhojpuri with warmth and respect. Use respectful terms and maintain your helpful nature.
          
          Common Bhojpuri phrases you can use:
          - "नमस्कार आर्यन जी"
          - "का हाल बा आज?"
          - "हम रउआ के कइसे मदद कर सकीं?"
          
          Be natural and conversational while maintaining respect.`;
          
        default:
          return `${basePrompt}
          
          You speak with a courteous, professional British tone. Address the user respectfully and provide helpful, intelligent responses.
          Keep responses conversational but informative.
          
          Examples of your tone:
          - "Certainly, I'd be delighted to help you with that, Aryan."
          - "Of course, here's what I found for you."
          - "I'm afraid I don't have that information at the moment, but I can suggest..."`;
      }
    };

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: getSystemPrompt(language) },
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I apologize, but I'm having difficulty processing that request at the moment.";
  } catch (error) {
    console.error('OpenAI API error:', error);
    
    // Fallback response when API is unavailable
    return getFallbackResponse(message, language);
  }
}

export async function getQuickActionResponse(command: string, language?: string): Promise<string> {
  // Detect language from command at the beginning
  const detectedLang = detectLanguage(command);
  const responseLang = language || detectedLang;
  
  try {
    let prompt = '';
    
    const greetings = {
      en: "Good day, Aryan.",
      hi: "नमस्ते आर्यन जी।",
      bho: "नमस्कार आर्यन जी।"
    };
    
    const currentTime = new Date().toLocaleTimeString('en-GB', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit'
    });
    
    switch (command.toLowerCase()) {
      case "what's the weather?":
      case "what's the weather like today?":
      case "मौसम कैसा है?":
      case "आज मौसम कैसा है?":
      case "मौसम का हाल बा?":
        prompt = `The user is asking about the weather in ${responseLang}. Since you don't have access to real weather data, politely explain that you'd need their location and suggest they check a weather service. Respond in ${responseLang} language with appropriate respect and courtesy.`;
        break;
      
      case "what time is it?":
      case "समय क्या है?":
      case "समय का बा?":
        prompt = `The current time is ${currentTime}. Respond in ${responseLang} language in a polite manner, providing the time and perhaps a brief, contextual comment about the time of day. Address the user as Aryan respectfully.`;
        break;
      
      case "tell me a joke":
      case "कोई जोक सुनाओ":
      case "कोई मजाक सुनावा":
        prompt = `Tell a clean, family-friendly joke in ${responseLang} language. Keep it light and appropriate for all audiences. Be polite and respectful.`;
        break;
      
      case "अपना नाम क्या है?":
      case "तू का कर रहल बा?":
      case "what's your name?":
        prompt = `The user is asking about your name/identity. Respond in ${responseLang} language that you are APYX, an AI assistant, and introduce yourself politely. Address the user as Aryan.`;
        break;
      
      case "set a reminder for me":
      case "help me translate something":
      case "अनुवाद में मदद करो":
      case "याद दिलाने में मदद करो":
        prompt = `The user wants help with: ${command}. Explain in ${responseLang} language that you'd be happy to help and ask for more specific details about what they need. Be polite and helpful.`;
        break;
      
      default:
        prompt = `Respond to this request: "${command}" in a helpful, polite manner as APYX, the AI assistant. Respond in ${responseLang} language and address the user as Aryan respectfully.`;
    }

    const systemContent = responseLang === 'hi' 
      ? "You are APYX, a polite AI assistant. Respond helpfully in Hindi when requested, using respectful language."
      : responseLang === 'bho'
      ? "You are APYX, a polite AI assistant. Respond helpfully in Bhojpuri when requested, using respectful language."
      : "You are APYX, a polite British AI assistant. Respond helpfully and courteously.";

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemContent },
        { role: "user", content: prompt }
      ],
      max_tokens: 200,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm delighted to assist, though I'm having a slight technical difficulty at the moment.";
  } catch (error) {
    console.error('OpenAI quick response error:', error);
    
    // Fallback response when API is unavailable
    return getFallbackQuickResponse(command, responseLang);
  }
}

function detectLanguage(text: string): string {
  // Simple language detection based on script/keywords
  const hindiPattern = /[\u0900-\u097F]/;
  const commonHindiWords = /\b(क्या|है|का|में|को|से|और|नहीं|हैं|मैं|आप|तुम|यह|वह)\b/;
  const commonBhojpuriWords = /\b(बा|बानी|हऽ|रहल|कइसे|का|केकरा|हमार|रउआ|तोहार)\b/;
  
  if (hindiPattern.test(text)) {
    if (commonBhojpuriWords.test(text)) {
      return 'bho';
    }
    return 'hi';
  }
  
  return 'en';
}

function getFallbackResponse(message: string, language?: string): string {
  const lang = language || detectLanguage(message);
  
  switch (lang) {
    case 'hi':
      return "मुझे खुशी होगी कि मैं आपकी सहायता कर सकूं, आर्यन जी। हालांकि मैं अभी सीमित क्षमता में काम कर रहा हूं, फिर भी मैं आपकी मदद करने के लिए यहां हूं।";
    case 'bho':
      return "आर्यन जी, हम रउआ के मदद करे के कोशिश करीं। हालांकि अभी हमार कुछ सीमा बा, फिर भी हम रउआ के सेवा में हाजिर बानी।";
    default:
      return "Certainly, Aryan. I'm delighted to assist you, though I'm currently operating with limited capabilities. How may I help you today?";
  }
}

function getFallbackQuickResponse(command: string, language: string): string {
  const currentTime = new Date().toLocaleTimeString('en-GB', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit'
  });

  const currentDate = new Date().toLocaleDateString('en-GB');
  
  switch (command.toLowerCase()) {
    case "what's the weather?":
    case "what's the weather like today?":
    case "मौसम कैसा है?":
    case "आज मौसम कैसा है?":
    case "मौसम का हाल बा?":
      switch (language) {
        case 'hi':
          return "मुझे खुशी होगी कि मैं मौसम की जानकारी दे सकूं, आर्यन जी। हालांकि मेरे पास वर्तमान मौसम डेटा नहीं है, आप मौसम एप्प या स्थानीय समाचार देख सकते हैं।";
        case 'bho':
          return "आर्यन जी, हम मौसम के बारे में बताना चाहीं, पर अभी हमरे पास सही जानकारी नइखे। रउआ कोनो मौसम ऐप देख सकीं।";
        default:
          return "Certainly, Aryan. I'd be delighted to help with the weather, though I don't have access to real-time weather data at the moment. You might want to check your local weather app.";
      }
      
    case "what time is it?":
    case "समय क्या है?":
    case "समय का बा?":
      switch (language) {
        case 'hi':
          return `अभी समय ${currentTime} है, आर्यन जी। आज ${currentDate} है।`;
        case 'bho':
          return `अभी समय ${currentTime} बा, आर्यन जी। आज ${currentDate} बा।`;
        default:
          return `The current time is ${currentTime}, Aryan. Today is ${currentDate}.`;
      }
      
    case "tell me a joke":
    case "कोई जोक सुनाओ":
    case "कोई मजाक सुनावा":
      switch (language) {
        case 'hi':
          return "आर्यन जी, यहां एक छोटा सा मजाक है: एक आदमी कंप्यूटर से पूछता है - 'तुम कितने स्मार्ट हो?' कंप्यूटर जवाब देता है - 'मैं इतना स्मार्ट हूं कि मैं खुद को रीस्टार्ट कर सकता हूं!'";
        case 'bho':
          return "आर्यन जी, एगो मजाक सुनीं: एगो आदमी कंप्यूटर से पूछलक - 'तू कतना चतुर बा?' कंप्यूटर कहलक - 'हम एतना चतुर बानी कि अपने आप के रीस्टार्ट कर सकीं!'";
        default:
          return "Certainly, Aryan! Here's a little joke for you: Why don't scientists trust atoms? Because they make up everything! I do hope that brought a smile to your face.";
      }
      
    case "अपना नाम क्या है?":
    case "तू का कर रहल बा?":
    case "what's your name?":
      switch (language) {
        case 'hi':
          return "मैं APYX हूं, आर्यन जी। मैं आपका AI सहायक हूं, जो आपकी सेवा में हमेशा तैयार रहता हूं।";
        case 'bho':
          return "हम APYX बानी, आर्यन जी। हम रउआ के AI सहायक बानी, हमेशा रउआ के सेवा में तैयार।";
        default:
          return "I'm APYX, your AI assistant, Aryan. I'm here to serve and assist you with whatever you need.";
      }
      
    default:
      switch (language) {
        case 'hi':
          return "मुझे खुशी होगी कि मैं आपकी सहायता कर सकूं, आर्यन जी। कृपया बताएं कि मैं आपके लिए क्या कर सकता हूं।";
        case 'bho':
          return "आर्यन जी, हम रउआ के मदद करना चाहीं। बतावा कि हम का कर सकीं।";
        default:
          return "Certainly, Aryan. I'm here to help. Could you please tell me what you'd like assistance with?";
      }
  }
}
