import { useState } from 'react';
import { StatusBar } from '@/components/status-bar';
import { VoiceInterface } from '@/components/voice-interface';
import { ChatInterface } from '@/components/chat-interface';
import { SettingsPanel } from '@/components/settings-panel';
import { InstallPrompt } from '@/components/install-prompt';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Settings, 
  Bot, 
  Mic, 
  Brain, 
  Smartphone, 
  Cloud, 
  Bell, 
  Languages, 
  Laugh,
  Zap
} from 'lucide-react';
import { Message, VoiceSettings } from '@shared/types';
import { getQuickResponse } from '@/lib/openai-client';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [language, setLanguage] = useState('en');
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    speed: 1,
    pitch: 1,
    britishAccent: true,
  });
  const { speak } = useTextToSpeech();

  const handleNewMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };

  const handleNewResponse = (message: Message) => {
    setMessages(prev => [...prev, message]);
    setIsProcessing(false);
  };

  const handleVoiceTranscript = async (transcript: string, detectedLanguage: string) => {
    if (!transcript.trim()) return;

    // Update language if auto-detected different language
    if (detectedLanguage && detectedLanguage !== language) {
      setLanguage(detectedLanguage);
    }

    const userMessage: Message = {
      id: crypto.randomUUID(),
      content: transcript,
      sender: 'user',
      timestamp: new Date(),
    };

    handleNewMessage(userMessage);
    setIsProcessing(true);

    try {
      // Send detected language context with the request
      const response = await fetch('/api/quick-response', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          command: transcript,
          language: detectedLanguage || language 
        }),
      });

      if (!response.ok) {
        throw new Error(`Voice command failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        content: data.message,
        sender: 'assistant',
        timestamp: new Date(data.timestamp),
      };

      handleNewResponse(assistantMessage);
      
      // Speak the response with current language and voice settings
      speak(data.message, { 
        ...voiceSettings, 
        language: detectedLanguage || language 
      });
    } catch (error) {
      console.error('Failed to process voice command:', error);
      
      const errorMessage: Message = {
        id: crypto.randomUUID(),
        content: getErrorMessage(language),
        sender: 'assistant',
        timestamp: new Date(),
      };
      
      handleNewResponse(errorMessage);
    }
  };

  const getErrorMessage = (lang: string) => {
    switch (lang) {
      case 'hi':
        return 'मुझे खुशी होगी, लेकिन मुझे आपके आदेश को संसाधित करने में कुछ तकनीकी कठिनाई हो रही है। कृपया फिर से कोशिश करें।';
      case 'bho':
        return 'माफ करीं, हमरे कुछ तकनीकी दिक्कत हो रहल बा। कृपया फिर से कोशिश करीं।';
      default:
        return 'I apologize, but I encountered an error processing your voice command. Please try again.';
    }
  };

  const handleQuickAction = async (action: string) => {
    let command = '';
    switch (action) {
      case 'weather':
        command = "What's the weather like today?";
        break;
      case 'reminder':
        command = "Set a reminder for me";
        break;
      case 'translate':
        command = "Help me translate something";
        break;
      case 'joke':
        command = "Tell me a joke";
        break;
      default:
        return;
    }

    await handleVoiceTranscript(command, language);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-jarvis-dark via-jarvis-slate to-jarvis-dark">
      {/* Header */}
      <header className="relative z-10 p-4 md:p-6">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-jarvis-blue to-jarvis-accent rounded-full flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl md:text-3xl font-orbitron font-bold jarvis-accent animate-glow">
              APYX
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => setIsSettingsOpen(true)}
              variant="ghost"
              size="sm"
              className="rounded-full bg-jarvis-surface/50 backdrop-blur-sm border border-jarvis-blue/20 hover:border-jarvis-blue/50"
            >
              <Settings className="h-4 w-4 jarvis-accent" />
            </Button>
            
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-32 bg-jarvis-surface/50 backdrop-blur-sm border-jarvis-blue/20 jarvis-accent">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-jarvis-surface border-jarvis-blue/20">
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">हिंदी</SelectItem>
                <SelectItem value="bho">भोजपुरी</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Interface */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 md:px-6">
        <StatusBar 
          status="APYX is ready to assist" 
          isOnline={true} 
        />

        <VoiceInterface 
          onTranscript={handleVoiceTranscript}
          voiceSettings={voiceSettings}
          language={language}
          onLanguageChange={setLanguage}
          isProcessing={isProcessing}
        />

        <ChatInterface 
          messages={messages}
          onNewMessage={handleNewMessage}
          onNewResponse={handleNewResponse}
          selectedLanguage={language}
        />

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-jarvis-surface/30 backdrop-blur-md border-jarvis-blue/20 hover:border-jarvis-blue/50 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="jarvis-accent text-2xl mb-4">
                <Mic className="h-8 w-8" />
              </div>
              <CardTitle className="jarvis-accent mb-2">Voice Commands</CardTitle>
              <p className="text-sm jarvis-glow mb-4">Speak naturally in English, Hindi, or Bhojpuri</p>
              <ul className="text-xs text-slate-400 space-y-1">
                <li>• "What's the weather?" / "मौसम कैसा है?"</li>
                <li>• "अपना नाम क्या है?" / "What's your name?"</li>
                <li>• "तू का कर रहल बा?" / "What are you doing?"</li>
              </ul>
            </CardContent>
          </Card>
          
          <Card className="bg-jarvis-surface/30 backdrop-blur-md border-jarvis-blue/20 hover:border-jarvis-blue/50 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="jarvis-accent text-2xl mb-4">
                <Brain className="h-8 w-8" />
              </div>
              <CardTitle className="jarvis-accent mb-2">AI Intelligence</CardTitle>
              <p className="text-sm jarvis-glow mb-4">Powered by advanced GPT technology</p>
              <ul className="text-xs text-slate-400 space-y-1">
                <li>• Smart conversations</li>
                <li>• Knowledge Q&A</li>
                <li>• Language translation</li>
              </ul>
            </CardContent>
          </Card>
          
          <Card className="bg-jarvis-surface/30 backdrop-blur-md border-jarvis-blue/20 hover:border-jarvis-blue/50 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="jarvis-accent text-2xl mb-4">
                <Smartphone className="h-8 w-8" />
              </div>
              <CardTitle className="jarvis-accent mb-2">Cross Platform</CardTitle>
              <p className="text-sm jarvis-glow mb-4">Works on desktop and mobile devices</p>
              <ul className="text-xs text-slate-400 space-y-1">
                <li>• Progressive Web App</li>
                <li>• Offline capabilities</li>
                <li>• Install to home screen</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-jarvis-surface/30 backdrop-blur-md border-jarvis-blue/20 mb-8">
          <CardHeader>
            <CardTitle className="jarvis-accent flex items-center">
              <Zap className="mr-2 h-5 w-5" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button
                onClick={() => handleQuickAction('weather')}
                variant="outline"
                className="p-4 h-auto flex-col bg-jarvis-surface/50 border-jarvis-blue/20 hover:border-jarvis-blue/50 group"
              >
                <Cloud className="jarvis-accent h-6 w-6 mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm jarvis-glow">Weather</span>
              </Button>
              
              <Button
                onClick={() => handleQuickAction('reminder')}
                variant="outline"
                className="p-4 h-auto flex-col bg-jarvis-surface/50 border-jarvis-blue/20 hover:border-jarvis-blue/50 group"
              >
                <Bell className="jarvis-accent h-6 w-6 mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm jarvis-glow">Reminder</span>
              </Button>
              
              <Button
                onClick={() => handleQuickAction('translate')}
                variant="outline"
                className="p-4 h-auto flex-col bg-jarvis-surface/50 border-jarvis-blue/20 hover:border-jarvis-blue/50 group"
              >
                <Languages className="jarvis-accent h-6 w-6 mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm jarvis-glow">Translate</span>
              </Button>
              
              <Button
                onClick={() => handleQuickAction('joke')}
                variant="outline"
                className="p-4 h-auto flex-col bg-jarvis-surface/50 border-jarvis-blue/20 hover:border-jarvis-blue/50 group"
              >
                <Laugh className="jarvis-accent h-6 w-6 mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm jarvis-glow">Joke</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        voiceSettings={voiceSettings}
        onVoiceSettingsChange={setVoiceSettings}
      />

      {/* Install Prompt */}
      <InstallPrompt />

      {/* Footer */}
      <footer className="relative z-10 text-center py-8 text-slate-400 text-sm">
        <p>&copy; 2024 APYX AI Assistant. Built with ❤️ for the future.</p>
        <div className="mt-2 flex justify-center space-x-4">
          <span>Version 1.0.0</span>
          <span>•</span>
          <span>Connected</span>
        </div>
      </footer>
      
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div 
            className="absolute inset-0" 
            style={{
              backgroundImage: 'linear-gradient(rgba(14, 165, 233, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(14, 165, 233, 0.1) 1px, transparent 1px)',
              backgroundSize: '50px 50px'
            }}
          />
        </div>
        
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-jarvis-accent/30 rounded-full animate-ping" />
        <div 
          className="absolute top-1/3 right-1/4 w-1 h-1 bg-jarvis-blue/50 rounded-full animate-pulse" 
          style={{ animationDelay: '1s' }}
        />
        <div 
          className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 bg-jarvis-glow/40 rounded-full animate-ping" 
          style={{ animationDelay: '2s' }}
        />
      </div>
    </div>
  );
}
