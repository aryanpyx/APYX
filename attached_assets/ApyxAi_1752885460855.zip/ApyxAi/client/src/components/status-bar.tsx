import { useState, useEffect } from 'react';

interface StatusBarProps {
  status: string;
  isOnline: boolean;
}

export function StatusBar({ status, isOnline }: StatusBarProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-GB', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="mb-8 text-center">
      <div className="inline-flex items-center space-x-2 bg-jarvis-surface/30 backdrop-blur-md rounded-full px-6 py-3 border border-jarvis-blue/20">
        <div className={`w-2 h-2 rounded-full animate-pulse ${isOnline ? 'bg-emerald-400' : 'bg-red-400'}`} />
        <span className="text-sm jarvis-glow">{status}</span>
      </div>
      
      <div className="mt-4 jarvis-accent font-orbitron text-lg">
        {formatTime(currentTime)}
      </div>
    </div>
  );
}
