# APYX - AI Assistant Application

## Overview

APYX is a modern AI assistant application designed to mimic JARVIS from Iron Man, featuring a sophisticated voice interface with British accent support, real-time chat capabilities, and a sleek dark theme. The application is built as a full-stack TypeScript solution with a React frontend and Express.js backend, utilizing OpenAI's GPT-4 for conversational AI capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom JARVIS-inspired color scheme
- **State Management**: React Query (TanStack Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Voice Features**: Web Speech API for recognition and synthesis

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints for chat and quick responses
- **AI Integration**: OpenAI GPT-4 API for conversational capabilities
- **Session Management**: Express sessions with PostgreSQL storage

### Data Storage Solutions
- **Database**: PostgreSQL with full database integration and persistence
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Comprehensive schema with users, conversations, and messages
- **Current Storage**: DatabaseStorage class with PostgreSQL backend
- **Offline Functionality**: Intelligent fallback responses for OpenAI API quota issues
- **Persistence**: Full conversation and message history with metadata

## Key Components

### Voice Interface
- **Speech Recognition**: Browser-based speech-to-text using Web Speech API
- **Text-to-Speech**: Synthetic speech with British accent preference
- **Voice Controls**: Tap-to-speak functionality with visual feedback
- **Quick Commands**: Preset voice commands for common interactions

### Chat System
- **Real-time Messaging**: Instant chat interface with message history
- **AI Responses**: GPT-4 powered responses with JARVIS personality
- **Language Support**: Multi-language conversation capabilities (English, Hindi, Bhojpuri)
- **Database Persistence**: Server-side conversation and message storage with PostgreSQL
- **Offline Capability**: Intelligent fallback responses when OpenAI API quota is exceeded
- **Smart Commands**: Predefined responses for common queries (time, weather, jokes, identity)
- **Message Metadata**: Voice input tracking, language detection, and timestamps

### UI/UX Design
- **Theme**: Dark JARVIS-inspired design with blue accent colors
- **Responsive**: Mobile-first design with adaptive layouts
- **Components**: Comprehensive UI component library using Radix primitives
- **Animations**: Smooth transitions and hover effects

### Settings & Customization
- **Voice Settings**: Adjustable speech rate, pitch, and accent preferences
- **Theme Options**: Dark mode with customizable color schemes
- **Language Selection**: Multi-language support for conversations

## Data Flow

1. **User Input**: Voice or text input captured through interface components
2. **Processing**: Input sent to Express backend via REST API
3. **Database Storage**: User messages saved to PostgreSQL with conversation context
4. **AI Integration**: Backend forwards requests to OpenAI GPT-4 API with fallback system
5. **Response Generation**: AI generates contextual responses with JARVIS personality
6. **Persistence**: AI responses saved to database with metadata
7. **Output**: Responses delivered through chat interface and text-to-speech

## Database Schema

### Tables
- **users**: User accounts with preferences (language, voice settings)
- **conversations**: Chat sessions with titles, language settings, and timestamps
- **messages**: Individual messages with sender, content, language, and voice input tracking

### API Endpoints
- **POST /api/conversations**: Create new conversation
- **GET /api/conversations/:id**: Retrieve conversation details
- **GET /api/users/:userId/conversations**: Get user's conversation history
- **POST /api/messages**: Create new message
- **GET /api/conversations/:conversationId/messages**: Get conversation messages
- **POST /api/chat/persist**: Enhanced chat with database persistence
- **PATCH /api/users/:userId/preferences**: Update user preferences

## External Dependencies

### Core Dependencies
- **OpenAI API**: GPT-4 integration for conversational AI
- **Neon Database**: PostgreSQL hosting (configured for future use)
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework

### Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Type safety across the entire stack
- **Drizzle Kit**: Database migration and schema management
- **ESBuild**: Fast JavaScript/TypeScript bundling

### Browser APIs
- **Web Speech API**: Speech recognition and synthesis
- **MediaDevices API**: Microphone access for voice input

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite dev server with instant updates
- **Type Checking**: Real-time TypeScript validation
- **Database**: In-memory storage for rapid prototyping

### Production Build
- **Frontend**: Static build output served by Express
- **Backend**: Bundled Node.js application with external dependencies
- **Database**: PostgreSQL with Drizzle ORM migrations
- **Environment**: Configured for Replit deployment with automatic scaling

### Configuration Management
- **Environment Variables**: API keys and database URLs via process.env
- **Build Scripts**: Separate development and production configurations
- **Asset Management**: Static file serving with proper caching headers

The application is designed to be easily extensible, with a modular architecture that separates concerns between the AI logic, user interface, and data persistence layers. The current implementation focuses on core chat functionality while providing a foundation for advanced features like user authentication, conversation history, and enhanced AI capabilities.