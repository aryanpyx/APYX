import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface AnimatedMicrophoneProps {
  isListening: boolean;
  isWakeWordListening: boolean;
  className?: string;
  onClick?: () => void;
}

export function AnimatedMicrophone({ 
  isListening, 
  isWakeWordListening, 
  className, 
  onClick 
}: AnimatedMicrophoneProps) {
  const micVariants = {
    idle: {
      scale: 1,
      rotateY: 0,
      filter: "drop-shadow(0 0 0px rgba(14, 165, 233, 0))",
    },
    wakeWord: {
      scale: [1, 1.05, 1],
      rotateY: [0, 5, -5, 0],
      filter: "drop-shadow(0 0 10px rgba(14, 165, 233, 0.5))",
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    listening: {
      scale: [1, 1.2, 1],
      rotateY: [0, 15, -15, 0],
      filter: "drop-shadow(0 0 20px rgba(14, 165, 233, 0.8))",
      transition: {
        duration: 1,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  const pulseVariants = {
    idle: { scale: 0, opacity: 0 },
    wakeWord: {
      scale: [0, 1.5, 0],
      opacity: [0, 0.3, 0],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeOut"
      }
    },
    listening: {
      scale: [0, 2, 0],
      opacity: [0, 0.5, 0],
      transition: {
        duration: 0.8,
        repeat: Infinity,
        ease: "easeOut"
      }
    }
  };

  const getAnimationState = () => {
    if (isListening) return "listening";
    if (isWakeWordListening) return "wakeWord";
    return "idle";
  };

  return (
    <div className={cn("relative flex items-center justify-center", className)}>
      {/* Pulse rings */}
      <motion.div
        className="absolute inset-0 rounded-full border-2 border-sky-400"
        variants={pulseVariants}
        animate={getAnimationState()}
      />
      <motion.div
        className="absolute inset-0 rounded-full border border-sky-300"
        variants={pulseVariants}
        animate={getAnimationState()}
        style={{ animationDelay: "0.2s" }}
      />
      
      {/* Main microphone button */}
      <motion.button
        className={cn(
          "relative z-10 w-16 h-16 rounded-full flex items-center justify-center",
          "bg-gradient-to-br from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500",
          "shadow-lg transition-all duration-300",
          "border-2 border-sky-400/50",
          {
            "bg-gradient-to-br from-sky-400 to-sky-500 border-sky-300": isWakeWordListening,
            "bg-gradient-to-br from-red-500 to-red-600 border-red-400": isListening,
          }
        )}
        variants={micVariants}
        animate={getAnimationState()}
        onClick={onClick}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* 3D Microphone SVG */}
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          className="text-white drop-shadow-sm"
        >
          {/* Microphone body - main cylinder */}
          <ellipse
            cx="12"
            cy="10"
            rx="3"
            ry="4"
            fill="currentColor"
            fillOpacity="0.9"
          />
          
          {/* Microphone highlight */}
          <ellipse
            cx="11"
            cy="9"
            rx="1"
            ry="2"
            fill="white"
            fillOpacity="0.3"
          />
          
          {/* Microphone grille lines */}
          <line x1="10" y1="8" x2="14" y2="8" stroke="white" strokeWidth="0.5" opacity="0.4" />
          <line x1="10" y1="10" x2="14" y2="10" stroke="white" strokeWidth="0.5" opacity="0.4" />
          <line x1="10" y1="12" x2="14" y2="12" stroke="white" strokeWidth="0.5" opacity="0.4" />
          
          {/* Microphone stand */}
          <path
            d="M12 14v3M8 17h8"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            fill="none"
          />
          
          {/* Base */}
          <ellipse
            cx="12"
            cy="17"
            rx="4"
            ry="0.5"
            fill="currentColor"
            fillOpacity="0.6"
          />
          
          {/* Sound waves */}
          {(isListening || isWakeWordListening) && (
            <>
              <motion.path
                d="M18 10c0-3.5-2.5-6-6-6M6 10c0-3.5 2.5-6 6-6"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                fill="none"
                opacity="0.6"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 0.6 }}
                transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
              />
              <motion.path
                d="M20 10c0-4.5-3.5-8-8-8M4 10c0-4.5 3.5-8 8-8"
                stroke="currentColor"
                strokeWidth="1"
                strokeLinecap="round"
                fill="none"
                opacity="0.4"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 0.4 }}
                transition={{ duration: 0.7, repeat: Infinity, repeatType: "reverse", delay: 0.2 }}
              />
            </>
          )}
        </svg>
      </motion.button>
      
      {/* Status indicator */}
      <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
        <motion.div
          className={cn(
            "w-2 h-2 rounded-full",
            {
              "bg-gray-400": !isWakeWordListening && !isListening,
              "bg-yellow-400": isWakeWordListening && !isListening,
              "bg-red-400": isListening,
            }
          )}
          animate={{
            scale: isListening || isWakeWordListening ? [1, 1.2, 1] : 1,
          }}
          transition={{
            duration: 0.5,
            repeat: isListening || isWakeWordListening ? Infinity : 0,
          }}
        />
      </div>
    </div>
  );
}