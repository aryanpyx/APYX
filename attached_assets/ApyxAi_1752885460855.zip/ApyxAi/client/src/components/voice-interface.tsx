import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mic, MicOff, Volume2, VolumeX, User, UserCheck } from 'lucide-react';
import { useVoiceRecognition } from '@/hooks/use-voice-recognition';
import { useTextToSpeech, VoiceGender } from '@/hooks/use-text-to-speech';
import { AnimatedMicrophone } from '@/components/animated-microphone';
import { getQuickResponse } from '@/lib/openai-client';
import { VoiceSettings } from '@shared/types';

function getQuickCommands(language: string): string[] {
  switch (language) {
    case 'hi':
      return [
        "मौसम कैसा है?",
        "समय क्या है?",
        "कोई जोक सुनाओ",
        "तुम कौन हो?"
      ];
    case 'bho':
      return [
        "मौसम का हाल बा?",
        "समय का बा?",
        "कोई मजाक सुनावा",
        "तू कौन बा?"
      ];
    default:
      return [
        "What's the weather?",
        "What time is it?",
        "Tell me a joke",
        "Who are you?"
      ];
  }
}

interface VoiceInterfaceProps {
  onTranscript: (transcript: string, detectedLanguage: string) => void;
  voiceSettings: VoiceSettings;
  language: string;
  onLanguageChange: (language: string) => void;
  isProcessing: boolean;
}

export function VoiceInterface({ 
  onTranscript, 
  voiceSettings, 
  language, 
  onLanguageChange, 
  isProcessing 
}: VoiceInterfaceProps) {
  const { 
    isListening, 
    isSupported, 
    transcript, 
    detectedLanguage,
    isWakeWordListening,
    startListening, 
    stopListening, 
    resetTranscript, 
    setLanguage 
  } = useVoiceRecognition();
  
  const { 
    speak, 
    stop: stopSpeaking, 
    isSpeaking, 
    voiceGender, 
    setVoiceGender 
  } = useTextToSpeech();
  
  const [voicePrompt, setVoicePrompt] = useState('Wake word listening active...');
  const [realtimeResponse, setRealtimeResponse] = useState('');

  // Update language when changed externally
  useEffect(() => {
    setLanguage(language);
  }, [language, setLanguage]);

  // Handle transcript completion
  useEffect(() => {
    if (transcript && !isListening) {
      const finalDetectedLang = detectedLanguage || language;
      onTranscript(transcript, finalDetectedLang);
      
      // Auto-update language if different language detected
      if (detectedLanguage && detectedLanguage !== language) {
        onLanguageChange(detectedLanguage);
      }
      
      resetTranscript();
    }
  }, [transcript, isListening, detectedLanguage, language, onTranscript, onLanguageChange, resetTranscript]);

  // Update voice prompt based on state
  useEffect(() => {
    if (isListening) {
      setVoicePrompt(`Listening... ${detectedLanguage ? `(${detectedLanguage.toUpperCase()})` : ''}`);
    } else if (isProcessing) {
      setVoicePrompt('Processing your request...');
    } else if (isWakeWordListening) {
      setVoicePrompt('Say "Hey APYX" or "Hey Dude" to activate');
    } else {
      setVoicePrompt('Tap to speak with APYX');
    }
  }, [isListening, isProcessing, isWakeWordListening, detectedLanguage]);

  // Real-time response during listening
  useEffect(() => {
    if (transcript && isListening) {
      setRealtimeResponse(transcript);
    } else {
      setRealtimeResponse('');
    }
  }, [transcript, isListening]);

  const handleVoiceToggle = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening(language);
    }
  }, [isListening, stopListening, startListening, language]);

  const handleQuickCommand = useCallback(async (command: string) => {
    try {
      setVoicePrompt(`Processing: ${command}`);
      
      // Send language along with command
      const response = await fetch('/api/quick-response', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          command,
          language: language 
        }),
      });

      if (!response.ok) {
        throw new Error(`Quick response failed: ${response.statusText}`);
      }

      const data = await response.json();
      speak(data.message, { ...voiceSettings, language });
      onTranscript(command, language);
    } catch (error) {
      console.error('Quick command failed:', error);
      setVoicePrompt('Error processing command');
    }
  }, [language, voiceSettings, speak, onTranscript]);

  if (!isSupported) {
    return (
      <Card className="mb-6 bg-red-950/20 border-red-500/20">
        <CardContent className="pt-6">
          <div className="text-center text-red-400">
            Voice recognition is not supported in your browser.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Main Voice Interface */}
      <Card className="bg-gradient-to-br from-sky-950/20 to-blue-950/20 border-sky-500/20">
        <CardHeader>
          <CardTitle className="text-center flex items-center justify-center gap-2">
            <Volume2 className="w-5 h-5" />
            Voice Assistant
            {isWakeWordListening && <Badge variant="outline" className="bg-yellow-500/20 text-yellow-400">Wake Word Active</Badge>}
            {isListening && <Badge variant="outline" className="bg-red-500/20 text-red-400">Listening</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Voice Controls */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
            {/* Voice Gender Selection */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-400">Voice:</span>
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant={voiceGender === 'male' ? 'default' : 'outline'}
                  onClick={() => setVoiceGender('male')}
                  className="h-8"
                >
                  <User className="w-3 h-3 mr-1" />
                  Male
                </Button>
                <Button
                  size="sm"
                  variant={voiceGender === 'female' ? 'default' : 'outline'}
                  onClick={() => setVoiceGender('female')}
                  className="h-8"
                >
                  <UserCheck className="w-3 h-3 mr-1" />
                  Female
                </Button>
              </div>
            </div>

            {/* Language Selection */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-400">Language:</span>
              <Select value={language} onValueChange={onLanguageChange}>
                <SelectTrigger className="w-32 h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="hi">हिंदी</SelectItem>
                  <SelectItem value="bho">भोजपुरी</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Speech Control */}
            {isSpeaking && (
              <Button
                size="sm"
                variant="outline"
                onClick={stopSpeaking}
                className="h-8"
              >
                <VolumeX className="w-3 h-3 mr-1" />
                Stop Speech
              </Button>
            )}
          </div>

          {/* 3D Animated Microphone */}
          <div className="flex justify-center">
            <AnimatedMicrophone
              isListening={isListening}
              isWakeWordListening={isWakeWordListening}
              onClick={handleVoiceToggle}
              className="w-24 h-24"
            />
          </div>

          {/* Voice Status */}
          <div className="text-center space-y-2">
            <p className="text-lg font-medium text-sky-400">
              {voicePrompt}
            </p>
            
            {/* Real-time Response */}
            {realtimeResponse && (
              <div className="bg-sky-950/30 rounded-lg p-3 border border-sky-500/20">
                <p className="text-sm text-sky-300">
                  Speaking: "{realtimeResponse}"
                </p>
              </div>
            )}

            {/* Detected Language Badge */}
            {detectedLanguage && detectedLanguage !== language && (
              <Badge variant="outline" className="bg-green-500/20 text-green-400">
                Detected: {detectedLanguage.toUpperCase()}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Commands */}
      <Card className="bg-gradient-to-br from-purple-950/20 to-pink-950/20 border-purple-500/20">
        <CardHeader>
          <CardTitle className="text-center text-sm">Quick Commands</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap justify-center gap-2">
            {getQuickCommands(language).map((cmd, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleQuickCommand(cmd)}
                disabled={isProcessing}
                className="text-xs bg-purple-950/30 border-purple-500/20 hover:border-purple-400/50 hover:bg-purple-950/50"
              >
                "{cmd}"
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
